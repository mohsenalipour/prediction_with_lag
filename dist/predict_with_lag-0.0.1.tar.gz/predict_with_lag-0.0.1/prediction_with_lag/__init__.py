__author__ = """Mohsen Alipour"""
__email__ = 'alipour.sins@gmail.com'
__version__ = '0.0.1'


from prediction_with_lag.main import predict_n_days
